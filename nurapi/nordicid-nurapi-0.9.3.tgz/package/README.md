# @nordicid/nurapi

Core library for communicating with Nordic ID NUR RFID reader modules.

The main entry point is the **{@link NurApi}** class, which provides the complete API for connecting to a reader and performing all operations — inventory, tag read/write, configuration, streaming, and more.

## Quick Start

```typescript
import { NurApi } from '@nordicid/nurapi';
import '@nordicid/nurapi-node'; // registers ser:// and tcp:// transports

const reader = new NurApi();
await reader.connect('tcp://192.168.1.100');

// Read reader info
const info = await reader.getReaderInfo();
console.log(`Reader: ${info.name}, Serial: ${info.serial}`);

// Run inventory and fetch tags
const result = await reader.inventory();
const tags = await reader.fetchTags();
console.log(`Found ${result.tagsFound} tags`);
for (const tag of tags) {
  console.log(`  EPC: ${tag.epcHex}, RSSI: ${tag.rssi}`);
}

await reader.disconnect();
```

## Connection

NurApi uses **URI-based connection** — the transport is resolved automatically from a registry:

| URI scheme | Transport | Package |
|---|---|---|
| `tcp://host:port` | TCP socket | `@nordicid/nurapi-node` |
| `ser://COM3` | Serial port | `@nordicid/nurapi-node` |
| `ws://host:port` | WebSocket | `@nordicid/nurapi` (built-in) |
| `ser://request` | Web Serial (browser) | `@nordicid/nurapi-web` |
| `ble://request` | Web Bluetooth (browser) | `@nordicid/nurapi-web` |

Import the transport package to register its URI schemes:

```typescript
import '@nordicid/nurapi-node'; // registers ser:// and tcp://
// or
import '@nordicid/nurapi-web';  // registers ser:// and ble:// (browser)
```

Auto-reconnect is enabled by default with exponential backoff (1s to 30s).

## Events

NurApi emits typed events for connection state and reader notifications:

```typescript
// Connection lifecycle
reader.on('connecting', () => console.log('Connecting...'));
reader.on('connected', () => console.log('Connected'));
reader.on('disconnected', () => console.log('Disconnected'));

// Streaming inventory
reader.on('inventoryStream', (event) => {
  console.log(`Tags so far: ${event.tagsAdded}`);
});

// GPIO / sensor changes
reader.on('ioChange', (event) => {
  console.log(`IO event: source=${event.source}, dir=${event.dir}`);
});
```

## Streaming Inventory

For continuous tag reading, use streaming inventory instead of polling:

```typescript
reader.on('inventoryStream', (event) => {
  const tags = reader.tagStorage.getAll();
  console.log(`${tags.length} unique tags seen`);
});

await reader.startInventoryStream();
// ... tags arrive via events ...
await reader.stopInventoryStream();
```

## Accessory Extension

For Nordic ID handheld devices (EXA51, EXA31, etc.), the `NurAccessoryExt` class provides control over device-specific features:

```typescript
import { NurApi, NurAccessoryExt, AccLedMode } from '@nordicid/nurapi';

const reader = new NurApi();
const acc = new NurAccessoryExt(reader);
await reader.connect('ble://request');

// Device info
const fw = await acc.getFwVersion();
const battery = await acc.getBatteryInfo();
console.log(`FW: ${fw}, Battery: ${battery.percentage}%`);

// LED, vibration, beep
await acc.setLed(AccLedMode.BLINK);
await acc.vibrate(200, 2);
await acc.beep(500);

// Barcode scanning (async — result via notification)
await acc.readBarcodeAsync(5000);

// Imager control
await acc.imagerAim(true);
await acc.imagerTrigger();

// Sensor API
const sensors = await acc.sensorEnumerate();
for (const s of sensors) {
  console.log(`Sensor ${s.source}: type=${s.type}`);
}

// Configuration
const cfg = await acc.getConfig();
cfg.deviceName = 'MyScanner';
await acc.setConfig(cfg);
```

## Gen2 Version 2

For advanced EPC Gen2v2 tag operations (Authenticate, ReadBuffer, Untraceable), the `NurGen2v2` class provides a standalone API:

```typescript
import { NurApi, NurGen2v2, Gen2v2TidOp, Gen2v2RangeOp } from '@nordicid/nurapi';

const reader = new NurApi();
const gen2v2 = new NurGen2v2(reader);
await reader.connect('tcp://192.168.1.100');

// Authenticate with a tag
const authResult = await gen2v2.authenticate({
  csi: 1,
  message: new Uint8Array([0x01, 0x02, 0x03, 0x04]),
  messageBitLength: 32,
});
console.log(`Auth status: ${authResult.status}, data: ${authResult.data}`);

// Read tag's internal buffer
const bufResult = await gen2v2.readBuffer({ bitAddress: 0, bitCount: 128 });
console.log(`Read ${bufResult.bitLength} bits`);

// Configure tag privacy
await gen2v2.untraceable({
  password: 0xDEADBEEF,
  assertU: true,
  hideEpc: false,
  tidOp: Gen2v2TidOp.HIDE_NONE,
  hideUser: false,
  rangeOp: Gen2v2RangeOp.NORMAL,
});
```

### ISO 29167-10 Tag Authentication (TAM)

The `NurGen2v2` class also supports ISO 29167-10 Tag Authentication Methods (TAM1 and TAM2), built on top of Gen2v2 Authenticate with AES-128 decryption:

```typescript
import { NurApi, NurGen2v2, TamMemoryProfile } from '@nordicid/nurapi';

const reader = new NurApi();
const gen2v2 = new NurGen2v2(reader);
await reader.connect('tcp://192.168.1.100');

const aesKey = new Uint8Array(16); // Your 16-byte AES-128 key

// TAM1 — simple challenge-response authentication
const tam1Result = await gen2v2.tam1({ keyNum: 0, key: aesKey });
console.log(`Authenticated: ${tam1Result.ok}`);

// TAM2 — authentication with custom data retrieval
const tam2Result = await gen2v2.tam2({
  keyNum: 0,
  key: aesKey,
  mpi: TamMemoryProfile.TID,
  offset: 0,
  blockCount: 2,
  protMode: 0,
});
if (tam2Result.ok) {
  console.log(`TID data: ${tam2Result.blockData}`);
}
```
